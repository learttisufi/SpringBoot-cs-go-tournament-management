package com.example.ninth_assigment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NinthAssigmentApplicationTests {

    @Test
    void contextLoads() {
    }

}
