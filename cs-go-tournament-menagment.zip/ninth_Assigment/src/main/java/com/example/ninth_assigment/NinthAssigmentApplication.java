package com.example.ninth_assigment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NinthAssigmentApplication {

    public static void main(String[] args) {
        SpringApplication.run(NinthAssigmentApplication.class, args);
    }

}
